import "../../App.css"

export default function Experiencias() {
  return <h1 className="Experiencias">experiencias</h1>
}
