// Versión simplificada de exportación a PDF sin dependencias externas

export const exportToPdf = async (portfolioData, elementId = "portfolio-preview-container") => {
  try {
    // Mostrar mensaje de carga
    const loadingToast = showLoadingToast("Preparando para imprimir...")

    // Obtener el elemento que contiene el portafolio
    const element = document.getElementById(elementId)
    if (!element) {
      throw new Error("Elemento no encontrado")
    }

    // Crear una copia del elemento para manipularlo sin afectar la vista original
    const printContainer = document.createElement("div")
    printContainer.innerHTML = element.innerHTML
    printContainer.style.position = "absolute"
    printContainer.style.left = "-9999px"
    printContainer.style.top = "-9999px"
    printContainer.style.width = "210mm" // Ancho A4
    printContainer.style.backgroundColor = "#ffffff"
    printContainer.style.padding = "20mm"
    printContainer.style.fontSize = "12pt"
    document.body.appendChild(printContainer)

    // Aplicar estilos para impresión
    const style = document.createElement("style")
    style.innerHTML = `
      @media print {
        body * {
          visibility: hidden;
        }
        #print-container, #print-container * {
          visibility: visible;
        }
        #print-container {
          position: absolute;
          left: 0;
          top: 0;
          width: 100%;
        }
        .preview-section-header button {
          display: none !important;
        }
        @page {
          size: A4;
          margin: 20mm;
        }
      }
    `
    printContainer.id = "print-container"
    document.head.appendChild(style)

    // Ocultar botones de edición
    const editButtons = printContainer.querySelectorAll(".edit-section-button")
    editButtons.forEach((button) => {
      button.style.display = "none"
    })

    // Cerrar mensaje de carga
    hideLoadingToast(loadingToast)

    // Mostrar mensaje de instrucciones
    showSuccessToast("Utiliza la función de impresión del navegador para guardar como PDF")

    // Abrir diálogo de impresión
    setTimeout(() => {
      window.print()

      // Limpiar después de imprimir
      setTimeout(() => {
        document.body.removeChild(printContainer)
        document.head.removeChild(style)
      }, 1000)
    }, 500)

    return true
  } catch (error) {
    console.error("Error al exportar a PDF:", error)
    showErrorToast("Error al generar el PDF. Inténtalo de nuevo.")
    return false
  }
}

// Funciones auxiliares para mostrar mensajes
const showLoadingToast = (message) => {
  // Crear elemento de toast
  const toast = document.createElement("div")
  toast.className = "pdf-loading-toast"
  toast.innerHTML = `
    <div class="pdf-toast-content">
      <div class="pdf-toast-spinner"></div>
      <span>${message}</span>
    </div>
  `

  // Estilos para el toast
  toast.style.position = "fixed"
  toast.style.bottom = "20px"
  toast.style.right = "20px"
  toast.style.backgroundColor = "#333"
  toast.style.color = "#fff"
  toast.style.padding = "15px 20px"
  toast.style.borderRadius = "5px"
  toast.style.zIndex = "9999"
  toast.style.display = "flex"
  toast.style.alignItems = "center"
  toast.style.boxShadow = "0 4px 12px rgba(0,0,0,0.15)"

  // Estilos para el spinner
  const style = document.createElement("style")
  style.innerHTML = `
    .pdf-toast-content {
      display: flex;
      align-items: center;
      gap: 10px;
    }
    .pdf-toast-spinner {
      width: 20px;
      height: 20px;
      border: 2px solid #f3f3f3;
      border-top: 2px solid #13f0c4;
      border-radius: 50%;
      animation: spin 1s linear infinite;
    }
    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }
  `
  document.head.appendChild(style)

  // Añadir al DOM
  document.body.appendChild(toast)

  return toast
}

const hideLoadingToast = (toast) => {
  if (toast && toast.parentNode) {
    toast.parentNode.removeChild(toast)
  }
}

const showSuccessToast = (message) => {
  // Crear elemento de toast
  const toast = document.createElement("div")
  toast.className = "pdf-success-toast"
  toast.innerHTML = `
    <div class="pdf-toast-content">
      <i class="fas fa-check-circle" style="color: #13f0c4;"></i>
      <span>${message}</span>
    </div>
  `

  // Estilos para el toast
  toast.style.position = "fixed"
  toast.style.bottom = "20px"
  toast.style.right = "20px"
  toast.style.backgroundColor = "#333"
  toast.style.color = "#fff"
  toast.style.padding = "15px 20px"
  toast.style.borderRadius = "5px"
  toast.style.zIndex = "9999"
  toast.style.display = "flex"
  toast.style.alignItems = "center"
  toast.style.boxShadow = "0 4px 12px rgba(0,0,0,0.15)"

  // Añadir al DOM
  document.body.appendChild(toast)

  // Eliminar después de 3 segundos
  setTimeout(() => {
    if (toast.parentNode) {
      toast.parentNode.removeChild(toast)
    }
  }, 3000)
}

const showErrorToast = (message) => {
  // Crear elemento de toast
  const toast = document.createElement("div")
  toast.className = "pdf-error-toast"
  toast.innerHTML = `
    <div class="pdf-toast-content">
      <i class="fas fa-exclamation-circle" style="color: #ff6b6b;"></i>
      <span>${message}</span>
    </div>
  `

  // Estilos para el toast
  toast.style.position = "fixed"
  toast.style.bottom = "20px"
  toast.style.right = "20px"
  toast.style.backgroundColor = "#333"
  toast.style.color = "#fff"
  toast.style.padding = "15px 20px"
  toast.style.borderRadius = "5px"
  toast.style.zIndex = "9999"
  toast.style.display = "flex"
  toast.style.alignItems = "center"
  toast.style.boxShadow = "0 4px 12px rgba(0,0,0,0.15)"

  // Añadir al DOM
  document.body.appendChild(toast)

  // Eliminar después de 3 segundos
  setTimeout(() => {
    if (toast.parentNode) {
      toast.parentNode.removeChild(toast)
    }
  }, 3000)
}
