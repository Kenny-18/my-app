"use client"

import CardItem from "../components/CardItem"

export default function SyntheticV0PageForDeployment() {
  return <CardItem />
}